#!/bin/bash

set -x

apt-get install --yes virtualbox-guest-utils
