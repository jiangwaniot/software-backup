<!-- For general purpose questions, use Stack Overflow http://stackoverflow.com/questions/tagged/hyperledger -->

## Description
<!-- Describe your issue or user story in detail -->

## Describe How to Reproduce
<!-- If an issue, provide sufficient context and steps to reproduce the issue -->
